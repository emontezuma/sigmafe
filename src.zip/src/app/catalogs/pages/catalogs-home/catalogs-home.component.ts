import { Component } from '@angular/core';

@Component({
  selector: 'app-catalogs-home',
  templateUrl: './catalogs-home.component.html',
  styleUrls: ['./catalogs-home.component.scss']
})
export class CatalogsHomeComponent {

}
