import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './checklists-home.component.html',
  styleUrls: ['./checklists-home.component.scss']
})
export class ChecklistsHomeComponent {

}
