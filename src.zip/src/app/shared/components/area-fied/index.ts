export * from './area-field.component';
export * from './area-field.module';
