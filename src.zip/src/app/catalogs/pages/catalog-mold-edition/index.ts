export * from './catalog-mold-edition.component';
