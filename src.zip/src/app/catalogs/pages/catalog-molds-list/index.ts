export * from './catalog-molds-list.component';
