import { OptionsScrollDirective } from './options-scroll.directive';

describe('OptionsScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new OptionsScrollDirective(null);
    expect(directive).toBeTruthy();
  });
});
