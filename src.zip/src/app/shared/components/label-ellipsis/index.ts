export * from './label-ellipsis.component';
export * from './label-ellipsis.module';
